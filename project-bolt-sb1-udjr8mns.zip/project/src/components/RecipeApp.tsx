import React, { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./ui/tabs";
import { Card, CardContent } from "./ui/card";
import { ScrollArea } from "./ui/scroll-area";
import { Input } from "./ui/input";
import { Checkbox } from "./ui/checkbox";

const tips = [
  {
    title: "Situações de Crise",
    items: [
      "🧘 Respiração Guiada: inspire por 4s, segure por 4s, expire por 4s.",
      "📦 Espaço Seguro: crie um cantinho com fones abafadores, brinquedos sensoriais, cobertores pesados.",
      "🗣️ Comunicação Visual: use cartões com carinhas para expressar emoções.",
      "🎧 Sons Calmantes: ofereça música suave ou ruído branco.",
      "⏳ Tempo de Acalmar: use um timer visual ou ampulheta para momentos tranquilos."
    ]
  },
  {
    title: "Dificuldade para Dormir",
    items: [
      "🔄 Rotina Noturna Visual: banho 🛁 → pijama 👕 → história 📖 → dormir 💤.",
      "🌿 Chá de Camomila com Maçã morno antes de dormir.",
      "🤲 Massagem leve nas costas, mãos ou pés.",
      "📘 História Tranquila narrada em tom suave.",
      "💤 Atividades Relaxantes: empurrar a parede, enrolar no cobertor como burrito."
    ]
  },
  {
    title: "Exercícios Pós-Refeição",
    items: [
      "🚶 Caminhada Leve: 5 a 10 minutos no quintal ou corredor para ajudar na digestão.",
      "🧸 Alongamento com Brincadeira: tocar os pés, levantar os braços, fingir ser uma árvore.",
      "🏃 Pular como Sapo: estimula a coordenação motora e gasto de energia.",
      "🪁 Brincar com Bolhas de Sabão: soprar bolhas ajuda na respiração e relaxamento.",
      "🪑 Senta-Levanta: exercício simples usando uma cadeira, ideal para propriocepção."
    ]
  }
];

const recipes = {
  cafe: [
    {
      title: "Panqueca de Banana",
      description: "Panqueca macia e nutritiva",
      ingredients: ["Banana madura", "Aveia", "Canela", "Mel"],
      benefits: "Rica em fibras e potássio",
      glutenFree: true,
      dairyFree: true,
      diet: true
    }
  ],
  almoco: [
    {
      title: "Arroz Colorido",
      description: "Arroz com legumes coloridos",
      ingredients: ["Arroz integral", "Cenoura", "Milho", "Ervilha"],
      benefits: "Vitaminas e minerais essenciais",
      glutenFree: true,
      dairyFree: true,
      diet: true
    }
  ],
  jantar: [
    {
      title: "Sopa de Legumes",
      description: "Sopa nutritiva e reconfortante",
      ingredients: ["Batata", "Cenoura", "Abobrinha", "Cebola"],
      benefits: "Fácil digestão e rica em nutrientes",
      glutenFree: true,
      dairyFree: true,
      diet: true
    }
  ],
  sobremesa: [
    {
      title: "Gelatina Colorida",
      description: "Sobremesa divertida e refrescante",
      ingredients: ["Gelatina sem açúcar", "Frutas"],
      benefits: "Baixa caloria e divertida",
      glutenFree: true,
      dairyFree: true,
      diet: true
    }
  ],
  veganas: [
    {
      title: "Cookies de Aveia",
      description: "Cookies crocantes e saudáveis",
      ingredients: ["Aveia", "Banana", "Cacau", "Tâmaras"],
      benefits: "Sem ingredientes de origem animal",
      glutenFree: true,
      dairyFree: true,
      diet: true
    }
  ],
  saudaveis: [
    {
      title: "Smoothie Verde",
      description: "Bebida nutritiva e refrescante",
      ingredients: ["Espinafre", "Banana", "Maçã", "Água de coco"],
      benefits: "Rico em vitaminas e minerais",
      glutenFree: true,
      dairyFree: true,
      diet: true
    }
  ]
};

export default function RecipeApp() {
  const [filters, setFilters] = useState({ glutenFree: false, dairyFree: false, diet: false });
  const [searchTerm, setSearchTerm] = useState("");

  const handleFilterChange = (filter: string) => {
    setFilters({ ...filters, [filter]: !filters[filter] });
  };

  const applyFilters = (items: any[]) => {
    return items.filter((item) => {
      if (filters.glutenFree && !item.glutenFree) return false;
      if (filters.dairyFree && !item.dairyFree) return false;
      if (filters.diet && !item.diet) return false;
      if (searchTerm && !item.title.toLowerCase().includes(searchTerm.toLowerCase())) return false;
      return true;
    });
  };

  return (
    <div className="p-4 max-w-screen-md mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">Receitas Especiais</h1>
      <p className="text-center text-muted-foreground mb-6">
        Desenvolvido para atender às preferências e necessidades de crianças com autismo.
      </p>

      <div className="flex flex-wrap gap-4 justify-center mb-6">
        <label className="flex items-center space-x-2">
          <Checkbox
            checked={filters.glutenFree}
            onCheckedChange={() => handleFilterChange("glutenFree")}
          />
          <span>Sem Glúten</span>
        </label>
        <label className="flex items-center space-x-2">
          <Checkbox
            checked={filters.dairyFree}
            onCheckedChange={() => handleFilterChange("dairyFree")}
          />
          <span>Sem Lactose</span>
        </label>
        <label className="flex items-center space-x-2">
          <Checkbox
            checked={filters.diet}
            onCheckedChange={() => handleFilterChange("diet")}
          />
          <span>Diet</span>
        </label>
      </div>

      <div className="mb-6">
        <Input
          placeholder="Buscar receita..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <Tabs defaultValue="cafe" className="w-full">
        <TabsList className="grid grid-cols-3 md:grid-cols-6 gap-2 overflow-x-auto">
          <TabsTrigger value="cafe">Café</TabsTrigger>
          <TabsTrigger value="almoco">Almoço</TabsTrigger>
          <TabsTrigger value="jantar">Jantar</TabsTrigger>
          <TabsTrigger value="sobremesa">Sobremesas</TabsTrigger>
          <TabsTrigger value="veganas">Veganas</TabsTrigger>
          <TabsTrigger value="saudaveis">Saudáveis</TabsTrigger>
          <TabsTrigger value="dicas">Dicas</TabsTrigger>
        </TabsList>
        {Object.entries(recipes).map(([key, items]) => (
          <TabsContent key={key} value={key} className="mt-4">
            <ScrollArea className="h-[300px]">
              <div className="grid gap-4">
                {applyFilters(items).map((recipe, index) => (
                  <Card key={index} className="rounded-2xl shadow-md">
                    <CardContent className="p-4">
                      <h2 className="text-xl font-semibold mb-1">{recipe.title}</h2>
                      <p className="text-muted-foreground text-sm mb-2">{recipe.description}</p>
                      <p className="text-sm font-medium">Ingredientes principais:</p>
                      <ul className="list-disc list-inside text-sm mb-2">
                        {recipe.ingredients?.map((ing: string, idx: number) => (
                          <li key={idx}>{ing}</li>
                        ))}
                      </ul>
                      <p className="text-sm italic text-muted-foreground">{recipe.benefits}</p>
                    </CardContent>
                  </Card>
                ))}
                {applyFilters(items).length === 0 && (
                  <p className="text-center text-muted-foreground">
                    Nenhuma receita atende aos filtros selecionados.
                  </p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        ))}
        <TabsContent value="dicas" className="mt-4">
          <ScrollArea className="h-[300px]">
            <div className="grid gap-4">
              {tips.map((tip, idx) => (
                <Card key={idx} className="rounded-2xl shadow-md">
                  <CardContent className="p-4">
                    <h2 className="text-xl font-semibold mb-2">{tip.title}</h2>
                    <ul className="list-disc list-inside text-sm text-muted-foreground">
                      {tip.items.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
}