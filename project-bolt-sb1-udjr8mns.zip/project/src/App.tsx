import React from 'react';
import { Heart, Users, Brain, MessageCircle, Calendar, Star } from 'lucide-react';
import RecipeApp from './components/RecipeApp';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-purple-50">
      {/* Seção do Cabeçalho */}
      <header className="bg-white/80 backdrop-blur-sm shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="w-8 h-8 text-blue-500" />
              <h1 className="text-2xl font-bold text-blue-900">Conexão Autismo</h1>
            </div>
            <nav className="hidden md:flex gap-6">
              <a href="#recursos" className="text-gray-600 hover:text-blue-500">Recursos</a>
              <a href="#comunidade" className="text-gray-600 hover:text-blue-500">Comunidade</a>
              <a href="#suporte" className="text-gray-600 hover:text-blue-500">Suporte</a>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        {/* Conteúdo Principal */}
        <section className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-900 mb-6">
            Juntos no Desenvolvimento do Seu Filho
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Compartilhando experiências e construindo um futuro mais inclusivo para crianças com autismo grau 1.
          </p>
          <div className="grid md:grid-cols-3 gap-8 text-left">
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <Users className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Comunidade Ativa</h3>
              <p className="text-gray-600">Conecte-se com outras famílias que compartilham experiências similares.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <Calendar className="w-12 h-12 text-purple-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Rotinas & Atividades</h3>
              <p className="text-gray-600">Estratégias práticas para organizar o dia a dia do seu filho.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <Star className="w-12 h-12 text-yellow-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Desenvolvimento</h3>
              <p className="text-gray-600">Acompanhe e celebre cada conquista no desenvolvimento.</p>
            </div>
          </div>
        </section>

        {/* Seção de Suporte */}
        <section className="bg-white rounded-2xl p-8 mb-16 shadow-lg">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold text-center mb-8 text-blue-900">
              Como Podemos Ajudar?
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex gap-4 items-start">
                <MessageCircle className="w-8 h-8 text-blue-500 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold mb-2">Grupos de Apoio</h4>
                  <p className="text-gray-600">Participe de conversas com outras famílias e compartilhe experiências.</p>
                </div>
              </div>
              <div className="flex gap-4 items-start">
                <Heart className="w-8 h-8 text-red-500 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold mb-2">Suporte Emocional</h4>
                  <p className="text-gray-600">Encontre acolhimento e compreensão em nossa comunidade.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Seção de Receitas */}
        <section className="mb-16">
          <RecipeApp />
        </section>

        {/* Chamada para Ação */}
        <section className="text-center max-w-2xl mx-auto">
          <h3 className="text-2xl font-bold mb-4 text-blue-900">
            Faça Parte da Nossa Comunidade
          </h3>
          <p className="text-gray-600 mb-8">
            Junte-se a outras famílias que estão transformando desafios em oportunidades de crescimento.
          </p>
          <button className="bg-blue-500 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-600 transition-colors shadow-md hover:shadow-lg flex items-center gap-2 mx-auto">
            <Heart className="w-5 h-5" />
            <span>Começar Agora</span>
          </button>
        </section>
      </main>

      <footer className="bg-gray-50 mt-20 py-8">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© 2024 Conexão Autismo. Juntos pelo desenvolvimento.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;